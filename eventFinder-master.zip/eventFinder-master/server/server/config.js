/**
 * Created by HP on 20-Dec-17.
 */
module.exports = {
    secret : '232kjh9d8jdw98u3cj892eurdwjiow3u2jfd9823u409'
};