/**
 * Created by HP on 07-Jan-18.
 */
export default [
    {
        "resource_uri": "https://www.eventbriteapi.com/v3/categories/103/",
        "id": "103",
        "name": "Music",
        "name_localized": "Music",
        "short_name": "Music",
        "short_name_localized": "Music"
    },
    {
        "resource_uri": "https://www.eventbriteapi.com/v3/categories/101/",
        "id": "101",
        "name": "Business & Professional",
        "name_localized": "Business & Professional",
        "short_name": "Business",
        "short_name_localized": "Business"
    },
    {
        "resource_uri": "https://www.eventbriteapi.com/v3/categories/110/",
        "id": "110",
        "name": "Food & Drink",
        "name_localized": "Food & Drink",
        "short_name": "Food & Drink",
        "short_name_localized": "Food & Drink"
    },
    {
        "resource_uri": "https://www.eventbriteapi.com/v3/categories/113/",
        "id": "113",
        "name": "Community & Culture",
        "name_localized": "Community & Culture",
        "short_name": "Community",
        "short_name_localized": "Community"
    },
    {
        "resource_uri": "https://www.eventbriteapi.com/v3/categories/105/",
        "id": "105",
        "name": "Performing & Visual Arts",
        "name_localized": "Performing & Visual Arts",
        "short_name": "Arts",
        "short_name_localized": "Arts"
    },
]