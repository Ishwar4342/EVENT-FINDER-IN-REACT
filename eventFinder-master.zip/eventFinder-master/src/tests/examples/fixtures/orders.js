/**
 * Created by HP on 15-Dec-17.
 */
export default [
    {
        category: 'PIZZA',
        title: 'Cremeschnitte',
        price: 4,
        description : 'test description',
        amount : undefined
    },
    {
        category: 'PASTA',
        title: 'Linguine',
        price: 5.5,
        description : 'test description',
        amount : undefined
    },
    {
        category: 'DESSERT',
        title: 'Margherita',
        price: 7,
        description : 'test description',
        amount : undefined
    },
]