/**
 * Created by HP on 23-Dec-17.
 */
import React from 'react';

export default class PageNotFound extends React.Component {
    render(){
        return(
            <h1>HOMePAGE</h1>
        )
    }
}